# HealthLens AI — QR Health Profile MVP

## Problem
In urgent or resource-limited care settings, a patient may not have a concise, accessible record of allergies, reported conditions, or medication information available.

## Solution
HealthLens AI is a consent-led QR identity concept. The QR contains a token only; the prototype retrieves a synthetic profile after the user confirms permission and shows a plain-language, rule-based summary.

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Create a virtual environment (recommended): `python -m venv .venv`
4. Activate it, then install dependencies: `pip install -r requirements.txt`
5. Run: `streamlit run healthlens_qr_prototype.py`
6. Open the local URL printed in the terminal.

## Demo tokens
- `HL-DEMO-104`
- `HL-DEMO-205`

The app can generate downloadable QR images for both demo tokens. In this MVP, scanning is simulated by entering the token shown under the QR. The demo does not use a real camera scanner, hosted database, authentication service, or a medical AI model.

## Production roadmap
- Patient-controlled sharing with time-limited consent
- Secure API and encrypted database; QR stores no clinical details
- Verified identity, role-based access, audit logs, revocation, and rate limits
- Optional OCR for uploaded reports only with explicit consent and clinician review
- Multilingual summaries with uncertainty labels and no autonomous diagnosis
- Clinical validation, accessibility testing, and legal/privacy review

## Safety
All records are synthetic. Do not enter real patient information. This is an educational prototype, not a medical device, diagnostic system, or substitute for professional care.
