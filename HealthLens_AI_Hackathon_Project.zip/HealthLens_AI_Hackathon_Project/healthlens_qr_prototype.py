import streamlit as st
import qrcode
from io import BytesIO
from datetime import date

st.set_page_config(page_title="HealthLens AI | QR Health Profile", page_icon="🩺", layout="wide")

st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#07152f 0%,#0b2447 55%,#102f59 100%); color:#f5f8ff;}
h1,h2,h3,p,label,span,div {color:inherit;}
[data-testid="stMetric"] {background:#102e52; padding:16px; border-radius:14px; border:1px solid #2c5e8d;}
.stButton>button {background:#22a7ff; color:#06162c; border:0; border-radius:10px; font-weight:700;}
.card {background:#10294a; border:1px solid #28517a; border-radius:16px; padding:18px; margin-bottom:12px;}
.muted {color:#b8c9e3;}
</style>
""", unsafe_allow_html=True)

PROFILES = {
    "HL-DEMO-104": {
        "name": "Aarav Sharma", "age": 28, "blood": "O+", "allergies": ["Penicillin"],
        "conditions": ["Asthma (reported)"], "medications": ["Rescue inhaler (reported)"],
        "emergency": "Emergency contact: Demo Contact • 000-000-0104",
        "notes": "Patient-reported history. Confirm details with the patient."
    },
    "HL-DEMO-205": {
        "name": "Meera Das", "age": 46, "blood": "B+", "allergies": ["No known allergies recorded"],
        "conditions": ["Type 2 diabetes (reported)"], "medications": ["Medication list not provided"],
        "emergency": "Emergency contact: Demo Contact • 000-000-0205",
        "notes": "Patient-reported history. Confirm details with the patient."
    }
}

st.markdown("<div class='muted'>PRIVACY-FIRST HEALTH ACCESS • STUDENT HACKATHON MVP</div>", unsafe_allow_html=True)
st.title("🩺 HealthLens AI")
st.subheader("A portable, consent-led health profile for faster, clearer care.")
st.write("Demonstration only — use synthetic profiles, not real patient information. This tool does not diagnose disease or replace a clinician.")

left, right = st.columns([1, 1.15], gap="large")
with left:
    st.markdown("<div class='card'><h3>1 · Choose a demo QR identity</h3><p class='muted'>Each QR contains a demo token only. It does not contain the medical profile.</p></div>", unsafe_allow_html=True)
    token = st.selectbox("Demo identity", list(PROFILES.keys()))
    qr = qrcode.QRCode(box_size=8, border=3)
    qr.add_data(token)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#07152f", back_color="white")
    bio = BytesIO()
    img.save(bio, format="PNG")
    st.image(bio.getvalue(), caption=f"QR token: {token}", width=230)
    st.download_button("Download demo QR (PNG)", data=bio.getvalue(), file_name=f"{token}.png", mime="image/png")
    typed_token = st.text_input("Simulate scan — enter the token", value=token, help="In this MVP, enter the token printed under the QR. A production version would use a camera scanner and authenticated API.")
    consent = st.checkbox("I have permission to view this demo profile.")
    reveal = st.button("Retrieve health profile", use_container_width=True)

with right:
    st.markdown("<div class='card'><h3>2 · Profile summary</h3><p class='muted'>Only a valid demo token plus consent reveals this synthetic profile.</p></div>", unsafe_allow_html=True)
    if reveal:
        if not consent:
            st.warning("Please confirm permission before viewing the profile.")
        elif typed_token.strip() not in PROFILES:
            st.error("Token not recognised. Check the demo token and try again.")
        else:
            p = PROFILES[typed_token.strip()]
            st.success("Demo profile retrieved. Always verify identity and information with the patient.")
            a,b,c = st.columns(3)
            a.metric("Patient", p["name"])
            b.metric("Age", p["age"])
            c.metric("Blood group", p["blood"])
            st.markdown("#### Safety-critical information")
            st.write("**Allergies:** " + ", ".join(p["allergies"]))
            st.write("**Reported conditions:** " + ", ".join(p["conditions"]))
            st.write("**Medication information:** " + ", ".join(p["medications"]))
            st.write(p["emergency"])
            st.markdown("#### AI-assisted plain-language summary")
            if "Asthma" in " ".join(p["conditions"]):
                summary = "The demo profile reports asthma and a rescue inhaler. Ask the patient about current symptoms, triggers, and the most recent treatment plan."
            elif "diabetes" in " ".join(p["conditions"]).lower():
                summary = "The demo profile reports type 2 diabetes. Confirm current medicines, allergies, and any recent glucose readings with the patient."
            else:
                summary = "Review the patient-reported history and confirm all details with the patient."
            st.info(summary)
            st.caption("This is a rule-based demo summary, not a clinical AI model or medical advice.")
    else:
        st.info("Select a demo identity, confirm permission, and press **Retrieve health profile** to run the workflow.")
        st.markdown("""
        <div class='card'>
        <h4>Prototype workflow</h4>
        <p>QR token → permission check → profile lookup → plain-language summary → clinician verifies details</p>
        </div>
        """, unsafe_allow_html=True)

st.divider()
st.markdown("### What this MVP demonstrates")
x,y,z = st.columns(3)
x.markdown("<div class='card'><h4>🔐 Privacy by design</h4><p>QR carries only a token, not medical data.</p></div>", unsafe_allow_html=True)
y.markdown("<div class='card'><h4>🧾 Portable summary</h4><p>Key patient-reported information is easier to review.</p></div>", unsafe_allow_html=True)
z.markdown("<div class='card'><h4>🌍 Rural-ready direction</h4><p>Designed for low-friction access and future multilingual support.</p></div>", unsafe_allow_html=True)
st.caption("Prototype status: educational MVP with synthetic data. Production deployment requires verified identity, patient-controlled consent, access logs, encryption, clinical validation, and applicable legal/privacy review.")
